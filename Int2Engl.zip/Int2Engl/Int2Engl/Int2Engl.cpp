// Int2Engl.cpp : applicationt to convert a number to the word it represents
//  10 > ten,   56 > fifty six
//Have three methods hund ten and single to unburden the code maybe even just two recallable blocks of code

#include "stdafx.h"
#include <iostream>
#include <string>
#include <stdlib.h>  //atoi()

using namespace std;

#ifndef INT2ENGL
#define INT2ENGL

class Int2Engl {
	private:
		string num;		

		int doubleDig(int); // 0 no, 1 yes
		void singleDig(int);
		void teens(int);
		void num2Engl(int);
		void section(int);
	public:
		Int2Engl();		
};

#endif

Int2Engl::Int2Engl()
{
	do{		//loop to prevent neg and decimal numbers
		cout << "Pick a positive number: ";
		getline(cin, num);
		cout << "\n";
	} while (num.find_first_not_of("0123456789") != num.npos);
	
	num2Engl(static_cast<int>(num.length()));
}

void Int2Engl::num2Engl(int numSize){

	int temp = numSize;

	if (num.compare("0") != 0){
		for (int i = 0; i < numSize; i++){
			
			if ((temp % 3) == 2){
				if (doubleDig(i) == 1){
					i++;
					temp--;						
				}
			}
			else {//if ((temp % 3) == 1 || (temp % 3) == 0){ // 0 = hundreds //// 1 = single postion.
				singleDig(i);					
				if ((temp % 3) == 0 && num[i] != '0'){
					cout << " hundred";
				}
				if ((temp % 3) == 1){
					section(temp);
				}
			} //end elseif
			temp--;
		}//end forloop
	}
	else{
		cout << "Zero";
	}
	cout << "\n";
}

void Int2Engl::teens(int c){
	switch (num[c])
	{
	case '0':
		cout << " ten";
		break;
	case '1':
		cout << " eleven";
		break;
	case '2':
		cout << " twelve";
		break;
	case '3':
		cout << " thirteen";
		break;
	case '4':
		cout << " fourteen";
		break;
	case '5':
		cout << " fifteen";
		break;
	case '6':
		cout << " sixteen";
		break;
	case '7':
		cout << " seventeen";
		break;
	case '8':
		cout << " eightteen";
		break;
	case '9':
		cout << " nineteen";
		break;
	default:
		cout << "\n ERROR: teens \n";
		break;
	}
}

int Int2Engl::doubleDig(int c){
	switch (num[c]){
	case '1':
		c++;
		teens(c);
		return 1;
		break;
	case '2':
		cout << " twenty";
		break;
	case '3':
		cout << " thirty";
		break;
	case '4':
		cout << " fourty";
		break;
	case '5':
		cout << " fifty";
		break;
	case '6':
		cout << " sixty";
		break;
	case '7':
		cout << " seventy";
		break;
	case '8':
		cout << " eighty";
		break;
	case '9':
		cout << " ninty";
		break;
	case '0':
		break;
	default:
		cout << "\n ERROR: doubles \n";
		break;
	}
	return 0;
}

void Int2Engl::singleDig(int c){
	switch (num[c]){
		case '1':			
			cout << " one";
			break;
		case '2':			
			cout << " two";
			break;
		case '3':			
			cout << " three";
			break;
		case '4':			
			cout << " four";
			break;
		case '5':			
			cout << " five";
			break;
		case '6':			
			cout << " six";
			break;
		case '7':			
			cout << " seven";
			break;
		case '8':			
			cout << " eight";
			break;
		case '9':			
			cout << " nine";
			break;
		case '0':
			break;
		default:
			cout << "\n ERROR: single \n";
			cout << c;
			break;
	}
}

void Int2Engl::section(int c){	
	switch (c){ // numlength() - c
		case 1:			
			break;
		case 4:
			cout << " thousand";
			break;
		case 7:
			cout << " million";
			break;
		case 10:
			cout << " billion";
			break;
		case 13:
			cout << " trillion";
			break;
		case 16:
			cout << " quadrillion";
			break;
		default:
			cout << " too high";
			break;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	Int2Engl i2e;
	//cout << num.at(0);  123456 output == 1
	//cout << num.at(4) << "\n";  output == 5

	system("pause");
	return 0;
}